import Foundation

struct Synonym: Codable {
    let word: String
    let score: Int
}
